plugins {
    id("com.android.application")
}

android {
    namespace = "com.abjad.mashriqi"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.abjad.mashriqi"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.18.0")
}
