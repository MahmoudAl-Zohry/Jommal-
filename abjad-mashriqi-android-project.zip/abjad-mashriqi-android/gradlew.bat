@echo off
setlocal
set "GRADLE_VERSION=9.6.0"
set "GRADLE_BASE=%USERPROFILE%\.gradle\abjad-distributions"
set "GRADLE_HOME=%GRADLE_BASE%\gradle-%GRADLE_VERSION%"
set "GRADLE_ZIP=%GRADLE_BASE%\gradle-%GRADLE_VERSION%-bin.zip"
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%GRADLE_BASE%" mkdir "%GRADLE_BASE%"
  if not exist "%GRADLE_ZIP%" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_ZIP%'"
    if errorlevel 1 exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%GRADLE_ZIP%' -DestinationPath '%GRADLE_BASE%' -Force"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
