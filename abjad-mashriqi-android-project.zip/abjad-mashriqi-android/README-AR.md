# حساب الجمل المشرقي — مشروع Android

هذا المشروع يغلّف ملف HTML الأصلي داخل تطبيق Android محلي يعمل دون إنترنت. لم تتم إعادة كتابة منطق الحساب.

## ما الذي أُعدّ؟

- تضمين صفحة `index.html` محليًا داخل التطبيق.
- تحميل الصفحة عبر `WebViewAssetLoader` على أصل HTTPS محلي بدل `file://`.
- تفعيل `localStorage` حتى يبقى الإعداد والسجل محفوظين بين مرات التشغيل.
- ربط النسخ واللصق بحافظة Android عبر جسر محدود.
- منع التنقل إلى المواقع الخارجية، وعدم إضافة إذن INTERNET.
- إبقاء الملف الأصلي دون تعديل في `original/`.

## البناء باستخدام Android Studio

المتطلبات:
- Android Studio حديث يدعم Android Gradle Plugin 9.5.0.
- JDK 17.
- Android SDK Platform 36 وBuild Tools المناسبة.
- اتصال بالإنترنت أثناء البناء الأول لتنزيل Gradle ومكتبة AndroidX WebKit؛ التطبيق الناتج لا يحتاج الإنترنت أثناء الاستخدام.
- أرفقت سكربتَي `gradlew` و`gradlew.bat` لتجهيز Gradle 9.6.0 تلقائيًا من خوادم Gradle الرسمية عند أول تشغيل.

الخطوات:
1. فك ضغط مجلد المشروع.
2. افتح مجلد `abjad-mashriqi-android` من Android Studio عبر **Open**.
3. اختر JDK 17 في إعداد Gradle عند الحاجة، ثم انتظر اكتمال Gradle Sync.
4. من القائمة اختر **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. ملف APK التجريبي يظهر في:
   `app/build/outputs/apk/debug/app-debug.apk`
6. انقل الملف إلى الهاتف وثبّته. قد يطلب Android السماح بالتثبيت من هذا المصدر.

## البناء من سطر الأوامر

بعد تثبيت Android SDK وJDK 17:

Linux / macOS:
```bash
./gradlew assembleDebug
```

Windows:
```bat
gradlew.bat assembleDebug
```

## ملاحظات التحقق

- `minSdk` هو 24 (Android 7.0 أو أحدث).
- `targetSdk` و`compileSdk` مضبوطتان على 36.
- اسم الحزمة: `com.abjad.mashriqi`.
- لا يوجد إذن `INTERNET` في Manifest.
- بيانات `localStorage` مرتبطة بتثبيت التطبيق؛ حذف التطبيق أو مسح بياناته قد يحذف السجل.
- هذا مشروع Debug قابل للبناء، وليس APK موقّعًا للنشر في متجر Google Play.
